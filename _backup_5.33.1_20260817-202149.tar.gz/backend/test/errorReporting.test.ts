/**
 * Cloud Error Reporting (v5.32.70) — src/monitoring/errorReporting.ts and the
 * captureError fan-out in src/monitoring/errors.ts.
 *
 * WHAT MAKES THIS WORTH TESTING. This integration is a magic string. Error
 * Reporting ingests a Cloud Logging entry only if it carries exactly
 * `type.googleapis.com/google.devtools.clouderrorreporting.v1beta1.ReportedErrorEvent`,
 * and grouping is only useful if `message` carries a stack trace. Every way of
 * getting those subtly wrong fails the same way the bug this replaces failed:
 * silently, with the app apparently fine and nobody being told anything.
 *
 * A test that asserted "reportError does not throw" would pass with the @type
 * key misspelled, with the stack omitted, with the payload written across two
 * lines, and with the whole thing disabled. So these assert the bytes that
 * reach stdout.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  initErrorReporting, reportError, buildReportedErrorEvent,
  isErrorReportingActive, _resetForTests,
} from "../src/monitoring/errorReporting.js";

const TYPE = "type.googleapis.com/google.devtools.clouderrorreporting.v1beta1.ReportedErrorEvent";

/** Capture what actually goes to stdout — the real integration surface. */
function captureStdout(): { lines: string[]; restore: () => void } {
  const lines: string[] = [];
  const spy = vi.spyOn(process.stdout, "write").mockImplementation((chunk: unknown) => {
    lines.push(String(chunk));
    return true;
  });
  return { lines, restore: () => spy.mockRestore() };
}

describe("Cloud Error Reporting — off unless enabled", () => {
  beforeEach(() => _resetForTests());
  afterEach(() => _resetForTests());

  it("is inert outside production, so a test run never files a real issue", () => {
    initErrorReporting({ service: "vyne-api", version: "5.32.70", enabled: false });
    expect(isErrorReportingActive()).toBe(false);
    const out = captureStdout();
    reportError(new Error("boom"));
    out.restore();
    expect(out.lines).toHaveLength(0);
  });

  it("never throws, whatever it is handed", () => {
    initErrorReporting({ service: "vyne-api", version: "5.32.70", enabled: true });
    const out = captureStdout();
    expect(() => reportError(new Error("boom"))).not.toThrow();
    expect(() => reportError("a string")).not.toThrow();
    expect(() => reportError(null)).not.toThrow();
    expect(() => reportError(undefined)).not.toThrow();
    const circular: Record<string, unknown> = {}; circular.self = circular;
    expect(() => reportError(new Error("boom"), circular)).not.toThrow();
    out.restore();
  });
});

describe("Cloud Error Reporting — the payload Google actually needs", () => {
  beforeEach(() => {
    _resetForTests();
    initErrorReporting({ service: "vyne-api", version: "5.32.70", enabled: true });
  });
  afterEach(() => _resetForTests());

  it("carries the exact @type marker — the whole integration is this string", () => {
    const e = buildReportedErrorEvent(new Error("boom"));
    expect(e["@type"]).toBe(TYPE);
    expect(e.severity).toBe("ERROR");
  });

  it("puts the STACK TRACE in message, not just the text", () => {
    // Without the stack, Error Reporting files every occurrence as a separate
    // issue and the console becomes a flat list rather than a count.
    const err = new Error("database is on fire");
    const e = buildReportedErrorEvent(err);
    expect(String(e.message)).toContain("database is on fire");
    expect(String(e.message)).toContain("errorReporting.test");
    expect(String(e.message).split("\n").length).toBeGreaterThan(1);
  });

  it("names the service and release, so a regression is dateable", () => {
    const e = buildReportedErrorEvent(new Error("boom"));
    expect(e.serviceContext).toEqual({ service: "vyne-api", version: "5.32.70" });
  });

  it("degrades sanely for a non-Error — a string, a null, an object", () => {
    expect(String(buildReportedErrorEvent("plain string").message)).toBe("plain string");
    expect(String(buildReportedErrorEvent({ code: 42 }).message)).toContain("42");
    expect(() => buildReportedErrorEvent(null)).not.toThrow();
  });

  it("scrubs query strings out of context, exactly like the Sentry path", () => {
    // A consulting product's URLs name the CUSTOMER'S customers. Logs are read
    // by more people than a monitoring console is, so staying inside GCP does
    // not make a client name in an error payload safe.
    const e = buildReportedErrorEvent(new Error("boom"), {
      url: "/api/solution-design?client=Acme%20Manufacturing",
      referer: "https://app/roadmap?code=ACME01",
      tenantId: "t-1",
    });
    const ctx = e.context as Record<string, unknown>;
    expect(ctx.url).toBe("/api/solution-design");
    expect(ctx.referer).toBe("https://app/roadmap");
    expect(ctx.tenantId).toBe("t-1");
    expect(JSON.stringify(e)).not.toContain("Acme");
    expect(JSON.stringify(e)).not.toContain("ACME01");
  });

  it("writes ONE line, so Cloud Logging parses it as one structured entry", () => {
    // A multi-line write is ingested as several unrelated text entries and the
    // @type marker is lost with them — the failure is total and silent.
    const out = captureStdout();
    reportError(new Error("multi\nline\nmessage"));
    out.restore();
    expect(out.lines).toHaveLength(1);
    expect(out.lines[0].endsWith("\n")).toBe(true);
    expect(out.lines[0].trimEnd()).not.toContain("\n");
    const parsed = JSON.parse(out.lines[0]);
    expect(parsed["@type"]).toBe(TYPE);
  });
});

describe("captureError fans out to every sink (v5.32.70)", () => {
  beforeEach(() => { vi.resetModules(); _resetForTests(); });
  afterEach(() => { vi.resetModules(); _resetForTests(); });

  it("reports to Cloud Error Reporting with NO Sentry DSN configured", async () => {
    // The v5.32.69 production state exactly: SENTRY_DSN unset. captureError
    // was a total no-op, so a lost billing row told nobody. That must not be
    // reachable again.
    const { initErrorReporting: init } = await import("../src/monitoring/errorReporting.js");
    const { captureError } = await import("../src/monitoring/errors.js");
    init({ service: "vyne-api", version: "5.32.70", enabled: true });

    const out = captureStdout();
    captureError(new Error("metering write FAILED"), { where: "safeMeter", tenantId: "t-9" });
    out.restore();

    expect(out.lines).toHaveLength(1);
    const parsed = JSON.parse(out.lines[0]);
    expect(parsed["@type"]).toBe(TYPE);
    expect(String(parsed.message)).toContain("metering write FAILED");
    expect((parsed.context as Record<string, unknown>).tenantId).toBe("t-9");
  });

  it("one sink failing does not cost us the other", async () => {
    const { initErrorReporting: init } = await import("../src/monitoring/errorReporting.js");
    const { captureError } = await import("../src/monitoring/errors.js");
    init({ service: "vyne-api", version: "5.32.70", enabled: true });

    // Sentry inactive and stdout throwing: captureError still must not throw.
    const spy = vi.spyOn(process.stdout, "write").mockImplementation(() => {
      throw new Error("stdout is gone");
    });
    expect(() => captureError(new Error("boom"))).not.toThrow();
    spy.mockRestore();
  });
});
